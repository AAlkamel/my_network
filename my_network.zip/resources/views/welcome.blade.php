<x-layout>
    <x-slot:title>Welcome</x-slot:title>
    <h1>Welcome to My Network</h1>
</x-layout>
