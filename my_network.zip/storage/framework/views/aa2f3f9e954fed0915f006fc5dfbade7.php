<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['highlight' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['highlight' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<a href="<?php echo e($attributes->get('href', '#')); ?>" class="block rounded-md border border-gray-300 p-4 shadow-sm  hover:shadow-xl sm:p-6 transition-all duration-300 ease-out">
    <div class="sm:flex sm:justify-between sm:gap-4 lg:gap-6">
        <div class="sm:order-last sm:shrink-0">
            <img alt=""
                src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1180&q=80"
                class="size-16 rounded-full object-cover sm:size-[72px]" />
        </div>

        <div class="mt-4 sm:mt-0">
            <h3 class="text-lg font-medium text-pretty text-gray-900">
                <?php echo e($title); ?>

            </h3>

            <div class="mt-4 line-clamp-2 text-sm text-pretty text-gray-700">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>

</a>
<?php /**PATH D:\herd\my_network\resources\views/components/card.blade.php ENDPATH**/ ?>